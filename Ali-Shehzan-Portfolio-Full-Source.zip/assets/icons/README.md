# Portfolio icons and language images

These SVG assets are stored locally so the portfolio does not depend on an icon CDN at runtime.

- Programming logos (`python.svg`, `java.svg`, `c.svg`, `bash.svg`, `powershell.svg`): [Devicon](https://github.com/devicons/devicon), from `icons/<name>/<name>-original.svg`. See `LICENSE-devicon.txt`. Logos remain the trademarks of their respective owners; use here identifies technologies in the portfolio.
- Country flags (`pk.svg`, `gb.svg`, `de.svg`, `fr.svg`): [flag-icons](https://github.com/lipis/flag-icons), from `flags/4x3/<country-code>.svg`. See `LICENSE-flag-icons.txt`.

Downloaded on 2026-10-24. The flags retain the country associations previously used in the portfolio.

The `cert-security.svg`, `cert-programming.svg`, `cert-ai.svg`, and `cert-cloud.svg` files are original vector category icons for the certification cards. They depict subject areas, rather than certification-provider branding.

The `github.svg` and `twitter.svg` brand icons come from [Bootstrap Icons](https://github.com/twbs/icons), from `icons/github.svg` and `icons/twitter.svg`. See `LICENSE-bootstrap-icons.txt`. Brand marks identify their respective services.

The `twitter-x.svg`, `facebook.svg`, `linkedin.svg`, and `instagram.svg` icons use the corresponding files from the same Bootstrap Icons collection. The portfolio uses `twitter-x.svg` for X (Twitter); the older bird asset is retained as an unused asset.
